import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyB-V9ZVZO82efuCPWsl085UPk-u4kZVkho",
  authDomain: "bibliotecaeletronica-c41b9.firebaseapp.com",
  projectId: "bibliotecaeletronica-c41b9",
  storageBucket: "bibliotecaeletronica-c41b9.appspot.com",
  messagingSenderId: "105676520485",
  appId: "1:105676520485:web:b7f839da40dbbd701453cc"
};


firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
